    $(document).ready(function () {
        $('.carousel').carousel({
            interval: 130000000
        });
    });